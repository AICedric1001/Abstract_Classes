<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laboratory Enrollment System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background: linear-gradient(135deg, #3498db, #8e44ad);
            background-size: 400% 400%;
            animation: gradientBackground 10s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .enrollment-box {
            padding: 20px;
            background-color: white;
            border: 2px solid #3498db;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            animation: fadeIn 2s ease;
        }

        h1 {
            font-size: 2.5em;
            color: #3498db;
        }

        table {
            margin: 0 auto;
        }

        @keyframes gradientBackground {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="enrollment-box">
        <h1>Laboratory Enrollment System</h1>
        <?php include 'enrollment.php'; ?>
    </div>
</body>
</html>
