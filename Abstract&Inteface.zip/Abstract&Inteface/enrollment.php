<?php

abstract class Student {
    protected $courses = [];

    abstract public function getDetails();

    public function enroll($course) {
        $this->courses[] = $course;
    }
}

interface CourseActions {
    public function addCourse($course);
    public function removeCourse($course);
}

class Undergraduate extends Student implements CourseActions {
    public function addCourse($course) {

        if ($course == 'Biology') {
            if (in_array('Chemistry', $this->courses)) {
                $this->enroll($course);
                echo "Enrolled in $course.<br>";
            } else {
                echo "Other Units not met for $course.<br>";
            }
        } else {
            $this->enroll($course);
            echo "Enrolled in $course.<br>";
        }
    }

    public function removeCourse($course) {
        $key = array_search($course, $this->courses);
        if ($key !== false) {
            unset($this->courses[$key]);
            echo "Dropped $course.<br>";
        }
    }

    public function getDetails() {
        echo "<h2>Student Details:</h2>";
        echo "Enrolled Courses: " . implode(', ', $this->courses);
    }
}

$student = new Undergraduate();
$student->addCourse('Physics');
$student->addCourse('Biology');
$student->addCourse('Chemistry');
$student->addCourse('Earth Science');
$student->getDetails();
?>